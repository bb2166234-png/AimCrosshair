package com.example.aimcrosshair

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("crosshair", MODE_PRIVATE) }
    private val styles = listOf("Classic +", "Dot", "Circle", "Cross", "Triangle", "Square", "T Cross", "Double +", "Star", "Aim Circle", "Diamond", "Target")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 13, 20)
        window.navigationBarColor = Color.rgb(9, 13, 20)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(Color.rgb(9, 13, 20))
        }
        val title = TextView(this).apply {
            text = "AIM CROSSHAIR"
            textSize = 26f
            setTextColor(Color.rgb(255, 48, 48))
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())
        val sub = TextView(this).apply {
            text = "Choose a style • Default color: Red"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(18))
        }
        root.addView(sub, matchWrap())

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        styles.forEachIndexed { index, name ->
            if (index % 2 == 0) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                addStyleButton(row, index, name)
                if (index + 1 < styles.size) addStyleButton(row, index + 1, styles[index + 1])
                grid.addView(row, matchWrap())
            }
        }
        root.addView(grid, matchWrap())

        val sizeLabel = TextView(this).apply {
            text = "Crosshair size: ${prefs.getInt("size", 42)}"
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(0, dp(18), 0, dp(4))
        }
        root.addView(sizeLabel, matchWrap())
        val sizeBar = SeekBar(this).apply {
            max = 80
            progress = prefs.getInt("size", 42) - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val size = progress + 20
                    prefs.edit().putInt("size", size).apply()
                    sizeLabel.text = "Crosshair size: $size"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) { refreshOverlayIfRunning() }
            })
        }
        root.addView(sizeBar, matchWrap())

        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("Red" to Color.RED, "Green" to Color.GREEN, "White" to Color.WHITE, "Blue" to Color.BLUE).forEach { (name, color) ->
            val b = Button(this).apply {
                text = name
                setOnClickListener {
                    prefs.edit().putInt("color", color).apply()
                    Toast.makeText(this@MainActivity, "$name selected", Toast.LENGTH_SHORT).show()
                    refreshOverlayIfRunning()
                }
            }
            colorRow.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { setMargins(dp(2), dp(4), dp(2), dp(4)) })
        }
        root.addView(colorRow, matchWrap())

        val start = Button(this).apply {
            text = "SHOW CROSSHAIR OVER APPS"
            setOnClickListener { startOverlay() }
        }
        root.addView(start, matchWrap())
        val stop = Button(this).apply {
            text = "HIDE CROSSHAIR"
            setOnClickListener { stopService(Intent(this@MainActivity, CrosshairOverlayService::class.java)) }
        }
        root.addView(stop, matchWrap())

        val note = TextView(this).apply {
            text = "Note: Android overlay permission is required. Compatibility with Free Fire MAX can vary by device and game version. This is a visual overlay only; it does not aim or fire automatically."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(14), 0, 0)
        }
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun addStyleButton(row: LinearLayout, index: Int, name: String) {
        val b = Button(this).apply {
            text = "${index + 1}. $name"
            setOnClickListener {
                prefs.edit().putInt("style", index).apply()
                Toast.makeText(this@MainActivity, "$name selected", Toast.LENGTH_SHORT).show()
                refreshOverlayIfRunning()
            }
        }
        row.addView(b, LinearLayout.LayoutParams(0, dp(52), 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
            Toast.makeText(this, "Allow 'Display over other apps', then return and tap Show", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, CrosshairOverlayService::class.java))
        Toast.makeText(this, "Crosshair enabled", Toast.LENGTH_SHORT).show()
    }

    private fun refreshOverlayIfRunning() {
        if (Settings.canDrawOverlays(this)) {
            stopService(Intent(this, CrosshairOverlayService::class.java))
            startService(Intent(this, CrosshairOverlayService::class.java))
        }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
