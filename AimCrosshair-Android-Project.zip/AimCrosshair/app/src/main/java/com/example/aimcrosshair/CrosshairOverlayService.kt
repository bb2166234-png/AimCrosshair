package com.example.aimcrosshair

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.min

class CrosshairOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var crosshairView: CrosshairView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = CrosshairView()
        crosshairView = view
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        windowManager.addView(view, params)
    }

    override fun onDestroy() {
        crosshairView?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        crosshairView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private inner class CrosshairView : View(this@CrosshairOverlayService) {
        private val prefs = getSharedPreferences("crosshair", MODE_PRIVATE)
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val color = prefs.getInt("color", Color.RED)
            val size = prefs.getInt("size", 42) * resources.displayMetrics.density / 2f
            val style = prefs.getInt("style", 0)
            val cx = width / 2f
            val cy = height / 2f
            val gap = min(size * 0.28f, 12f * resources.displayMetrics.density)
            val outer = size
            paint.color = color
            paint.alpha = 240
            paint.strokeWidth = 2.5f * resources.displayMetrics.density
            when (style) {
                0 -> { // classic plus with center gap
                    canvas.drawLine(cx - outer, cy, cx - gap, cy, paint); canvas.drawLine(cx + gap, cy, cx + outer, cy, paint)
                    canvas.drawLine(cx, cy - outer, cx, cy - gap, paint); canvas.drawLine(cx, cy + gap, cx, cy + outer, paint)
                }
                1 -> { paint.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, 3.5f * resources.displayMetrics.density, paint); paint.style = Paint.Style.STROKE }
                2, 9, 11 -> { canvas.drawCircle(cx, cy, outer * 0.7f, paint); if (style != 2) canvas.drawCircle(cx, cy, outer * 0.18f, paint); if (style == 11) { canvas.drawLine(cx - outer, cy, cx - outer * .45f, cy, paint); canvas.drawLine(cx + outer * .45f, cy, cx + outer, cy, paint); canvas.drawLine(cx, cy - outer, cx, cy - outer * .45f, paint); canvas.drawLine(cx, cy + outer * .45f, cx, cy + outer, paint) } }
                3 -> { canvas.drawLine(cx - outer, cy, cx + outer, cy, paint); canvas.drawLine(cx, cy - outer, cx, cy + outer, paint) }
                4 -> { val p = Path().apply { moveTo(cx, cy - outer); lineTo(cx - outer, cy + outer * .7f); lineTo(cx + outer, cy + outer * .7f); close() }; canvas.drawPath(p, paint) }
                5 -> canvas.drawRect(cx - outer * .7f, cy - outer * .7f, cx + outer * .7f, cy + outer * .7f, paint)
                6 -> { canvas.drawLine(cx - outer, cy, cx + outer, cy, paint); canvas.drawLine(cx, cy, cx, cy + outer, paint) }
                7 -> { canvas.drawLine(cx - outer, cy, cx - gap, cy, paint); canvas.drawLine(cx + gap, cy, cx + outer, cy, paint); canvas.drawLine(cx, cy - outer, cx, cy - gap, paint); canvas.drawLine(cx, cy + gap, cx, cy + outer, paint); canvas.drawCircle(cx, cy, gap * .35f, paint) }
                8 -> { for (i in 0..7) { val a = Math.PI * i / 4; canvas.drawLine(cx + (outer * .25f * kotlin.math.cos(a)).toFloat(), cy + (outer * .25f * kotlin.math.sin(a)).toFloat(), cx + (outer * kotlin.math.cos(a)).toFloat(), cy + (outer * kotlin.math.sin(a)).toFloat(), paint) } }
                10 -> { val p = Path().apply { moveTo(cx, cy - outer); lineTo(cx + outer, cy); lineTo(cx, cy + outer); lineTo(cx - outer, cy); close() }; canvas.drawPath(p, paint) }
            }
        }
    }
}
