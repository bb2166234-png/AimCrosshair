# Aim Crosshair (Android/Kotlin starter)

A starter Android Studio project for a visual crosshair overlay with 12 styles, red default color, basic color choices, and size control.

## Build
1. Install Android Studio on a computer and open this folder as a project.
2. Let Gradle sync and install the required Android SDK (API 35).
3. Connect an Android phone with USB debugging enabled, or use an emulator.
4. Press Run to install and test.
5. In the app, tap **SHOW CROSSHAIR OVER APPS** and grant the Android **Display over other apps** permission.

## Important
- This is source code, not a prebuilt APK.
- Overlay behavior and game compatibility vary by Android version/device/game version; test responsibly and follow the game's rules.
- The overlay is visual only. It does not provide auto-aim, recoil control, or auto-fire.
- For a production release, add a persistent notification/foreground-service handling, lifecycle checks, and test on target devices before publishing.
